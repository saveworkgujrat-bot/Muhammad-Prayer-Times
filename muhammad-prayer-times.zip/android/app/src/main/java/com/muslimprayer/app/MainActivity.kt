package com.muslimprayer.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.GeolocationPermissions
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Full screen web view
        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            setGeolocationEnabled(true)
            // cache parameters
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        // Add Android Javascript Interface Bridge to receive widget payload
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                // Auto consent coordinates request inside native containment
                callback?.invoke(origin, true, false)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                view?.loadUrl(url ?: "")
                return true
            }
        }

        // Load the production-deployed companion app URL
        webView.loadUrl("https://ais-pre-lry7mgefsdv4ax3t7qayq7-1038180630540.asia-southeast1.run.app")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    inner class AndroidBridge(private val context: Context) {
        @JavascriptInterface
        fun updateWidget(prayerTimesJson: String, nextPrayerName: String, nextPrayerCountdown: String, city: String) {
            val prefs: SharedPreferences = context.getSharedPreferences("PrayerWidgetPrefs", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putString("prayer_times_json", prayerTimesJson)
                putString("next_prayer_name", nextPrayerName)
                putString("next_prayer_countdown", nextPrayerCountdown)
                putString("current_city", city)
                apply()
            }

            // Immediately broadcast change trigger to active widgets
            val intent = Intent(context, PrayerWidgetProvider::class.java).apply {
                action = "com.muslimprayer.app.UPDATE_WIDGET"
            }
            context.sendBroadcast(intent)
        }
    }
}

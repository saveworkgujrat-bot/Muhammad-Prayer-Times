package com.muslimprayer.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.RemoteViews
import org.json.JSONObject

class PrayerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == "com.muslimprayer.app.UPDATE_WIDGET") {
            val appWidgetManager = AppWidgetManager.getInstance(context)
            val thisWidget = ComponentName(context, PrayerWidgetProvider::class.java)
            val allWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget)
            onUpdate(context, appWidgetManager, allWidgetIds)
        }
    }

    companion object {
        fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
            val prefs: SharedPreferences = context.getSharedPreferences("PrayerWidgetPrefs", Context.MODE_PRIVATE)
            val prayerTimesJson = prefs.getString("prayer_times_json", "{}")
            val nextPrayerName = prefs.getString("next_prayer_name", "-")
            val nextPrayerCountdown = prefs.getString("next_prayer_countdown", "--:--:--")
            val city = prefs.getString("current_city", "Gujrat, Pakistan")

            val views = RemoteViews(context.packageName, R.layout.prayer_widget_layout)

            views.setTextViewText(R.id.widget_prayer_name, nextPrayerName)
            views.setTextViewText(R.id.widget_countdown, nextPrayerCountdown)
            views.setTextViewText(R.id.widget_location, city)

            try {
                val json = JSONObject(prayerTimesJson)
                views.setTextViewText(R.id.time_fajr, json.optString("Fajr", "04:12"))
                views.setTextViewText(R.id.time_dhuhr, json.optString("Dhuhr", "12:15"))
                views.setTextViewText(R.id.time_asr, json.optString("Asr", "15:45"))
                views.setTextViewText(R.id.time_maghrib, json.optString("Maghrib", "19:02"))
                views.setTextViewText(R.id.time_isha, json.optString("Isha", "20:30"))
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Clicking the widget launches the app
            val intent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_title, pendingIntent)

            appWidgetManager.updateAppWidget(appWidgetId, views)
        }
    }
}
